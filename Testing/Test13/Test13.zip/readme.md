still antenna from ceiling

0 - facing antenna
45 - 45 degrees from antenna
90 - perpendicular to antenna

a - antenna 1 (Laird S9028PCLJ) 9 dBic
b - antenna 4 (Laird S9028PCLJ) 9 dBic
c - antenna 2 (Laird S9028PCRJ) 8 dBic
d - small antenna (Laird S9025PL) 5.5 dBic
e - small antenna (Laird S9025PR) 5.5 dBic
f - MT-242025/TRH/A (865-956 MHz)

# naming convention:
Test13[antenna]-[distance(ft)]-[angle(degrees)]

example:
Test13a-1-0
antenna a, 1 ft, 0 degrees


